# One file Express

## Installation

```
npm i

cp .env.txt .env
```

แก้ไขไฟล์ `.env ` เพื่อกำหนดค่าการเชื่อมต่อฐานข้อมูล

## Run

```
npm start
```
